import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _safeInit(() {
      _selectedEmotion =
          prefs.getString('ff_selectedEmotion') ?? _selectedEmotion;
    });
    _safeInit(() {
      _userDescription =
          prefs.getString('ff_userDescription') ?? _userDescription;
    });
    _safeInit(() {
      _Resultado = prefs.getString('ff_Resultado') ?? _Resultado;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  String _selectedEmotion = '';
  String get selectedEmotion => _selectedEmotion;
  set selectedEmotion(String value) {
    _selectedEmotion = value;
    prefs.setString('ff_selectedEmotion', value);
  }

  String _userDescription = '';
  String get userDescription => _userDescription;
  set userDescription(String value) {
    _userDescription = value;
    prefs.setString('ff_userDescription', value);
  }

  String _Resultado = '';
  String get Resultado => _Resultado;
  set Resultado(String value) {
    _Resultado = value;
    prefs.setString('ff_Resultado', value);
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
