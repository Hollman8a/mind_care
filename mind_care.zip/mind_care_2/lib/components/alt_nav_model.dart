import '/flutter_flow/flutter_flow_util.dart';
import 'alt_nav_widget.dart' show AltNavWidget;
import 'package:flutter/material.dart';

class AltNavModel extends FlutterFlowModel<AltNavWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
