import '/flutter_flow/flutter_flow_util.dart';
import 'alt_nav2_widget.dart' show AltNav2Widget;
import 'package:flutter/material.dart';

class AltNav2Model extends FlutterFlowModel<AltNav2Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
