import '/flutter_flow/flutter_flow_util.dart';
import 'message_bottom_sheet_widget.dart' show MessageBottomSheetWidget;
import 'package:flutter/material.dart';

class MessageBottomSheetModel
    extends FlutterFlowModel<MessageBottomSheetWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
