// Export pages
export '/des_estado/des_estado_widget.dart' show DesEstadoWidget;
export '/resultado/resultado_widget.dart' show ResultadoWidget;
export '/estado/estado_widget.dart' show EstadoWidget;
export '/home/home_widget.dart' show HomeWidget;
