import '/backend/api_requests/api_calls.dart';
import '/components/main_web_nav_widget.dart';
import '/components/mobile_nav_widget.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'des_estado_widget.dart' show DesEstadoWidget;
import 'package:flutter/material.dart';

class DesEstadoModel extends FlutterFlowModel<DesEstadoWidget> {
  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // Model for mainWebNav component.
  late MainWebNavModel mainWebNavModel;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController;
  String? Function(BuildContext, String?)? textControllerValidator;
  // Stores action output result for [Backend Call - API (ChatGPT)] action in Button widget.
  ApiCallResponse? aPIRespuesta;
  // Model for mobileNav component.
  late MobileNavModel mobileNavModel;

  @override
  void initState(BuildContext context) {
    mainWebNavModel = createModel(context, () => MainWebNavModel());
    mobileNavModel = createModel(context, () => MobileNavModel());
  }

  @override
  void dispose() {
    unfocusNode.dispose();
    mainWebNavModel.dispose();
    textFieldFocusNode?.dispose();
    textController?.dispose();

    mobileNavModel.dispose();
  }
}
